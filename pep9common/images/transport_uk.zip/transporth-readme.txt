Nathaniel Porter's Transport Heavy Font
==========================================
The Transport font is the principal font used on British road signs.

Installation Instructions (Windows)
===================================
1. Unzip transporth.ttf to the Desktop.
2. Go to Control Panel and open the Font manager.
3. Click File > Install New Font
4. Browse to where transporth.ttf was unzipped and select it
5. Click okay.

Since this font is TrueType it should function with most operating systems and should have no problems with Linux or MacOS although it has only been tested on various flavours of Windows - including XP.

Special Characters
==================
In Transport Heavy, all the alphanumeric characters are as normal, but there are also a few special characters available.

# = Space between route letter (A,B or M) and number, e.g. A 702
^ = "Get in lane" arrow 
< = Arrow right 
> = Arrow left 
/ = / 
\ = higher 
! = Feet 
" = Inches 
Alt + 0188 = 1/4 
Alt + 0189 = 1/2 
Alt + 0190 = 3/4 


Footnote
========
This font was made by Nathaniel Porter from images in the Department for Transport Proposed Revision of the Traffic Signs Regulations and General Directions documentation which can be found here: http://www.roads.dft.gov.uk/consult/traffic/regulations/10.htm

This font can be found online at http://www.allan-online.co.uk

It may not be used for commerical purposes.